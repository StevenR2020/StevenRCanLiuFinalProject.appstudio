var NetID = ""
var passWord = ""
var query2 = ""
var request2 = ""
var result2 = ""

btnLogin.onclick=function(){

NetID = iptNETID.value
    passWord = iptPASSWORD.value
    
    if(result2.length == 0) {
            NSB.MsgBox("Your information is not recognized")
            ChangeForm(SignUp)
            
    } else {
            let recognized = false
            for (i = 0; i <= request2.length - 1; i++)
              if (result2[i][0] == NetID && result2[i][1] == passWord) {
                  recognized = true
                  ChangeForm(accountOverview)
              }
            if (recognized == false) {
                alert("Login credentials are incorrect")
                NetId = ""
                password = ""
              }
            }





    query2 = "SELECT NetId, pass FROM user WHERE NetId = 'sar74677' AND pass = 'Creighton'"
    request2 = Ajax("https://ormond.creighton.edu/courses/375/ajax-connection.php", "GET", "host=ormond.creighton.edu&user=sar74677&pass=Aaron2020)&database=375groupa2&query="+query2)
    if (request2.status == 200){
       if (request2.responseText == 500){
        result2 = JSON.parse(request2.responseText)
        NSB.MsgBox("You have successfully logged into your account")
        ChangeForm(accountOverview)
       } else 
         alert("Your Login Credentials Were Invalid")
         
         
    }
         
         
}




btnSignUp.onclick=function(){
  ChangeForm(SignUp)
}

LoginPage.onshow=function(){
  imgHeader.src="https://ormond.creighton.edu/courses/375/Groups/Group-B2/images/CreightonLogo.jpg"
  
  //time for the header
  var timeApp=(new Date())
  timeApp=String(timeApp)
  timeApp=timeApp.substring(0,10)
  lblTime.value=timeApp
  
  
}