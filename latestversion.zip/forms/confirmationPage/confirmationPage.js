btnMakeAnotherLog.onclick=function(){
  ChangeForm(inptToDo)
}

btnGoBackToHomePage.onclick=function(){
  ChangeForm(HomePage)
}